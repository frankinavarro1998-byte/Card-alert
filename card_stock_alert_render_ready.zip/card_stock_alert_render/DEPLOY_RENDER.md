# Deploy Card Stock Alert on Render

This package is configured for a Render **paid Starter web service** with a 1 GB persistent disk. The persistent disk keeps your SQLite watchlist database and VAPID push keys across deploys and restarts.

## Fastest deployment

1. Create a new GitHub repository.
2. Upload **all files from this folder** to the repository root. Make sure `render.yaml` is at the top level.
3. Sign in to Render and choose **New > Blueprint**.
4. Connect the GitHub repository you just created.
5. Render will read `render.yaml` and show a service named `card-stock-alert`.
6. Review the plan/cost and click **Apply / Deploy Blueprint**.
7. When deployment finishes, open the generated `https://...onrender.com` address.
8. Test the health endpoint by opening `/api/health`. You should see JSON with `"ok": true`.
9. Open the main site on your Android phone in Chrome, add a product, then enable notifications.

## Why this uses a paid Starter service

This MVP stores data in SQLite and stores its web-push VAPID keys as files. Render free web services use an ephemeral filesystem, so those files can disappear whenever a free service restarts, redeploys, or spins down. A persistent disk avoids that.

## What Render runs

Build command:

```text
pip install -r requirements.txt
```

Start command:

```text
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

Health check:

```text
/api/health
```

Persistent data directory:

```text
/var/data
```

The app automatically stores `card_alert.db`, `vapid_private.pem`, and `vapid_public.txt` in that directory.

## Android app connection

After Render gives you a URL such as:

```text
https://card-stock-alert-xxxx.onrender.com
```

enter that full HTTPS URL in the Android app's server setting.

## Important

Retailer pages may change or block automated requests. The app does not bypass CAPTCHAs, queues, login protections, or anti-bot controls. If inventory cannot be determined reliably, the monitor reports `UNKNOWN` instead of guessing.
